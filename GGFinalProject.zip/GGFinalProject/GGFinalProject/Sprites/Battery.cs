﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace GGFinalProject.Sprites
{
    public class Battery : Sprite
    {
        public Battery(Texture2D texture) : base(texture)
        {


        }
        public override void Update(GameTime gameTime, List<Sprite> sprites)
        {

        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            base.Draw(spriteBatch);
        }
        /// <summary>
        /// providing sprite size information for collision check
        /// </summary>
        /// <returns>Bounds for collision check</returns>
        public Rectangle GetBounds()
        {
            return new Rectangle((int)Position.X, (int)Position.Y, _texture.Width, _texture.Height);
        }
        
    }
}
