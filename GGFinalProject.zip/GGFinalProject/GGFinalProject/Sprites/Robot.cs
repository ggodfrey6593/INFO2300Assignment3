﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GGFinalProject.Sprites
{
    public class Robot : Sprite
    {

        public Robot(Texture2D texture) : base(texture)
        {

        }

        public override void Update(GameTime gameTime, List<Sprite> sprites)
        {
            //creating rotation vectors for key presses
            Direction = new Vector2((float)Math.Cos(_rotation), (float)Math.Sin(_rotation));
            _previousKey = _currentKey;
            _currentKey = Keyboard.GetState();

            //creating forward movement
            if (_currentKey.IsKeyDown(Keys.Up))
            {
                Position += Direction * Speed;

            }
            //clockwise rotation
            if (_currentKey.IsKeyDown(Keys.Right))
            {
                _rotation += MathHelper.ToRadians(RotationSpeed);

            }
            //counter-clockwise rotation
            else if (_currentKey.IsKeyDown(Keys.Left))
            {
                _rotation -= MathHelper.ToRadians(RotationSpeed);
            }


        }
        /// <summary>
        /// Providing sprite size for collision checks
        /// </summary>
        /// <returns>sprite parameters</returns>
        public Rectangle GetBounds()
        {
            return new Rectangle((int)Position.X, (int)Position.Y, _texture.Width, _texture.Height);
        }

    }
}
