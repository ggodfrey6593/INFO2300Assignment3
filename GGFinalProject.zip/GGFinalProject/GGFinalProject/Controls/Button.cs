﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GGFinalProject.Controls
{
    public class Button : Component
    {
        /// <summary>
        /// Creating button font, texture, and mouse interactions
        /// </summary>
        #region Fields
        private MouseState _currentMouse;
        private SpriteFont _font;
        private MouseState _previousMouse;
        private Texture2D _texture;
        private bool _isHovering;
        #endregion
        /// <summary>
        /// Creating click event handler, button color, text, and location info
        /// </summary>
        #region Prop
        public event EventHandler Click;
        public bool Clicked { get; private set; }
        public Color PenColour {get; set;}
        public Rectangle Rectangle
        {
            get
            {
                return new Rectangle((int)Position.X, (int)Position.Y, 150, 50);
            }
        }
        public Vector2 Position {get; set;}
        public string Text { get; set; }
        #endregion
        /// <summary>
        /// declaring all button creation methods
        /// </summary>
        /// <param name="texture"></param>
        /// <param name="font"></param>
        #region Methods
        //Declaring font color and texture placement
        public Button(Texture2D texture, SpriteFont font)
        {
            _texture = texture;
            _font = font;
            PenColour = Color.Black;
        }
        //change the color of the button on mouse over
        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            var colour = Color.White;
            if (_isHovering)
            {
                colour = Color.Gray;
            }
            spriteBatch.Draw(_texture, Rectangle, colour);
            if (!string.IsNullOrEmpty(Text))
            {
                var x = (Rectangle.X + (Rectangle.Width / 2)) - (_font.MeasureString(Text).X / 2);
                var y = (Rectangle.Y + (Rectangle.Height / 2)) - (_font.MeasureString(Text).Y / 2);
                spriteBatch.DrawString(_font, Text, new Vector2(x, y), PenColour);
            }
        }
        //determining hover state and click state
        public override void Update(GameTime gameTime)
        {
            _previousMouse = _currentMouse;
            _currentMouse = Mouse.GetState();
            var mouseRectangle = new Rectangle(_currentMouse.X, _currentMouse.Y, 1, 1);
            _isHovering = false;

            if (mouseRectangle.Intersects(Rectangle))
            {
                _isHovering = true;
                if(_currentMouse.LeftButton == ButtonState.Released && _previousMouse.LeftButton == ButtonState.Pressed)
                {
                    Click?.Invoke(this, new EventArgs());
                }
            }
        }
        #endregion
    }
}
