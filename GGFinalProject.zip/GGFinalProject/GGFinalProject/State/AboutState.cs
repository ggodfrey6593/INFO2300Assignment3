﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GGFinalProject.Controls;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
namespace GGFinalProject.States
{
    public class AboutState : State
    {
        private SpriteFont aboutFont;
        private List<Component> _components;

        public AboutState(Game1 game, GraphicsDevice graphicsDevice, ContentManager content) : base(game, graphicsDevice, content)
        {
            //creating back button and loading sprite font for information
            aboutFont = content.Load<SpriteFont>("Fonts/Font");
            var buttonTexture = _content.Load<Texture2D>("Controls/button");
            var buttonFont = _content.Load<SpriteFont>("Fonts/Font");
            var backButton = new Button(buttonTexture, buttonFont)
            {
                Position = new Vector2(300, 350),
                Text = "BACK",
            };
            backButton.Click += backButton_Click;

            _components = new List<Component>()
            {
                backButton,
            };
        }
        /// <summary>
        /// Creating an event handler to take user back to main menu on back button click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void backButton_Click(object sender, EventArgs e)
        {
            _game.ChangeState(new MenuState(_game, _graphicsDevice, _content));
        }
        /// <summary>
        /// Drawing string for creater signature and drawing back button
        /// </summary>
        /// <param name="gameTime"></param>
        /// <param name="spriteBatch"></param>
        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
          
            spriteBatch.DrawString(aboutFont, "Created By: Graeme Godfrey", new Vector2(300,300), Color.Black);
            foreach (var component in _components)
            {
                component.Draw(gameTime, spriteBatch);
            }

            spriteBatch.End();
        }

        public override void PostUpdate(GameTime gameTime)
        {
        }

        public override void Update(GameTime gameTime)
        {
            foreach (var component in _components)
            {
                component.Update(gameTime);
            }
        }
    }
}
