﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GGFinalProject.Controls;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace GGFinalProject.States
{
    public class MenuState : State
    {
        //creating a list to hold components
        private List<Component> _components;

        //inside MenuState Creating parameters for each button and the text contents
        public MenuState(Game1 game, GraphicsDevice graphicsDevice, ContentManager content) : base(game, graphicsDevice, content)
        {
            var buttonTexture = _content.Load<Texture2D>("Controls/button");
            var buttonFont = _content.Load<SpriteFont>("Fonts/Font");

            #region Button Parameters
            var playButton = new Button(buttonTexture, buttonFont)
            {
                Position = new Vector2(300, 50),
                Text = "NEW GAME",
            };

            playButton.Click += playButton_Click;

            var controlsButton = new Button(buttonTexture, buttonFont)
            {
                Position = new Vector2(300, 150),
                Text = "CONTROLS",
            };

            controlsButton.Click += controlsButton_Click;

            var aboutButton = new Button(buttonTexture, buttonFont)
            {
                Position = new Vector2(300, 250),
                Text = "ABOUT",
            };

            aboutButton.Click += aboutButton_Click;

            var closeButton = new Button(buttonTexture, buttonFont)
            {
                Position = new Vector2(300, 350),
                Text = "CLOSE",
            };

            closeButton.Click += closeButton_Click;
            #endregion


            //populating list with button components
            _components = new List<Component>()
            {
                playButton,
                aboutButton,
                controlsButton,
                closeButton,
            };
        }
        /// <summary>
        /// Creating each click handler for menu items
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        #region clickHandlers
        private void closeButton_Click(object sender, EventArgs e)
        {
            _game.Exit();
        }

        private void aboutButton_Click(object sender, EventArgs e)
        {
            _game.ChangeState(new AboutState(_game, _graphicsDevice, _content));
        }

        private void controlsButton_Click(object sender, EventArgs e)
        {
            _game.ChangeState(new Controls(_game, _graphicsDevice, _content));
        }

        private void playButton_Click(object sender, EventArgs e)
        {
            _game.ChangeState(new GameState(_game, _graphicsDevice, _content));
        }
        #endregion

        /// <summary>
        /// Drawing all menu components
        /// </summary>
        /// <param name="gameTime"></param>
        /// <param name="spriteBatch"></param>
        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
            foreach (var component in _components)
            {
                component.Draw(gameTime, spriteBatch);
            }
            spriteBatch.End();
        }

        public override void PostUpdate(GameTime gameTime)
        {
            
        }
        /// <summary>
        /// Updating with all compenents in the list
        /// </summary>
        /// <param name="gameTime"></param>
        public override void Update(GameTime gameTime)
        {
            foreach (var component in _components)
            {
                component.Update(gameTime);
            }
        }
    }
}
