﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GGFinalProject.Controls;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace GGFinalProject.States
{
    public class Controls : State
    {
        private List<Component> _components;

        public Controls(Game1 game, GraphicsDevice graphicsDevice, ContentManager content) : base(game, graphicsDevice, content)
        {
            //Creating back button to navigate back to the main menu
            var buttonTexture = _content.Load<Texture2D>("Controls/button");
            var buttonFont = _content.Load<SpriteFont>("Fonts/Font");
            var backButton = new Button(buttonTexture, buttonFont)
            {
                Position = new Vector2(300, 350),
                Text = "BACK",
            };
            backButton.Click += backButton_Click;

            _components = new List<Component>()
            {
                backButton,
            };
        }
        /// <summary>
        /// Drawing instructions image and back button
        /// </summary>
        /// <param name="gameTime"></param>
        /// <param name="spriteBatch"></param>
        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            var controls = _content.Load<Texture2D>("Sprites/Controls");

            spriteBatch.Begin();
            spriteBatch.Draw(controls, new Rectangle(100, 50, 550, 280), Color.White);
            foreach (var component in _components)
            {
                component.Draw(gameTime, spriteBatch);
            }
            spriteBatch.End();
        }
        /// <summary>
        /// Navigating back to the main menu on click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void backButton_Click(object sender, EventArgs e)
        {
            _game.ChangeState(new MenuState(_game,_graphicsDevice,_content));
        }

        public override void PostUpdate(GameTime gameTime)
        {
          
        }

        public override void Update(GameTime gameTime)
        {
            foreach (var component in _components)
            {
                component.Update(gameTime);
            }

        }
    }
}
