﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GGFinalProject.Sprites;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace GGFinalProject.States
{
    public class GameState : State
    {
        /// <summary>
        /// Declaring all necessary class items
        /// </summary>
        #region Declarations
        private List<Sprite> _sprites;
        public int posX, posY;
        private Texture2D batteryTexture;
        private Texture2D robotTexture;
        private float Time = 10f;
        private float Score = 0f;
        private SpriteFont timeFont;
        private SpriteFont scoreFont;
        private Robot robot;
        private Battery battery;
        protected KeyboardState _currentKey;
        #endregion


        public GameState(Game1 game, GraphicsDevice graphicsDevice, ContentManager content) : base(game, graphicsDevice, content)
        {
            //creating random variable for battery location
            Random r = new Random();

            //instantiating fonts for timer and scoreboard
            timeFont = content.Load<SpriteFont>("Fonts/TimeFont");
            scoreFont = content.Load<SpriteFont>("Fonts/Score");

            //creating first random location for battery
            posX = r.Next(10, graphicsDevice.Viewport.Width - 10);
            posY = r.Next(30, graphicsDevice.Viewport.Height - 30);

            //loading texture for robot and battery
            batteryTexture = _content.Load<Texture2D>("Sprites/Battery");
            robotTexture = _content.Load<Texture2D>("Sprites/Robot");

            //instantiating robot with first location vector
            robot = new Robot(robotTexture)
            {
                Position = new Vector2(graphicsDevice.Viewport.Width / 2, 250),

                
            };
            
            //instantiating battery with first random location vector
            battery = new Battery(batteryTexture)
            {
                Position = new Vector2(posX, posY),

            };
            //adding items to sprites list
            _sprites = new List<Sprite>()
            {
                robot,
                battery,
            };
            //adding sound effects and theme song
            SoundEffect zurp = _content.Load<SoundEffect>("Sounds/bloop_x");
            Song theme = _content.Load<Song>("Sounds/Theme");
            MediaPlayer.Play(theme);
        }
        /// <summary>
        /// Drawing all game items
        /// </summary>
        /// <param name="gameTime"></param>
        /// <param name="spriteBatch"></param>
        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            
            spriteBatch.Begin();   

            //drawing both the scoreboard string and the time remainging string
            spriteBatch.DrawString(timeFont, "Time Remaining: " + Time.ToString("n"), new Vector2(300, 10), Color.Black);
            spriteBatch.DrawString(scoreFont, "Current Score: " + Score.ToString("n"), new Vector2(10, 10), Color.Red);

            //drawing each sprite in the list of sprites created in GameState
            foreach (var sprite in _sprites)
            {
                sprite.Draw(spriteBatch);
            }
            spriteBatch.End();
        }

        /// <summary>
        /// Adding all game interactions including colision and sound effects
        /// </summary>
        /// <param name="gameTime"></param>
        public override void Update(GameTime gameTime)
        {
            //adding sound effect for collision and game end
            SoundEffect zurp = _content.Load<SoundEffect>("Sounds/bloop_x");
            SoundEffect gameOver = _content.Load<SoundEffect>("Sounds/game_over");

            //getting current keyboard state for escape key check
            _currentKey = Keyboard.GetState();

            //creating new randoms for all subsequent battery spawns
            Random r = new Random();
            posX = r.Next(10, 600);
            posY = r.Next(30, 400);

            //Getting collision rectangles
            var robotRec = robot.GetBounds();
            var batteryRec = battery.GetBounds();

            //updating remaining time and score strings
            Score += (float)gameTime.ElapsedGameTime.TotalSeconds;
            Time -= (float)gameTime.ElapsedGameTime.TotalSeconds;

            //creating collision to move the battery, add time to the clock, and play sound effect
           if(robotRec.Intersects(batteryRec))
           {
                zurp.Play(volume:0.2f,pitch: 0.0f,pan: 0.0f);
                Time += 3;
                battery.Position = new Vector2(posX, posY);
           }

           //checking for out of time, and ending game
           if (Time <= 0)
           {
                _game.ChangeState(new MenuState(_game, _graphicsDevice, _content));
                MediaPlayer.Stop();
                gameOver.Play(volume:0.5f,pitch:0.0f,pan:0.0f);
           }

           //checking and accepting user input to leave the game using the escape key
            if (_currentKey.IsKeyDown(Keys.Escape))
            {
                _game.ChangeState(new MenuState(_game, _graphicsDevice, _content));
                MediaPlayer.Stop();
                gameOver.Play(volume: 0.5f, pitch: 0.0f, pan: 0.0f);
            }


            foreach (var sprite in _sprites.ToArray())
            {
                sprite.Update(gameTime, _sprites);
            }

            PostUpdate(gameTime);


        }

        public override void PostUpdate(GameTime gameTime)
        {
            for (int i = 0; i < _sprites.Count; i++)
            {
                if (_sprites[i].IsRemoved)
                {
                    _sprites.RemoveAt(i);
                    i--;
                }
            }
        }



    }
}
